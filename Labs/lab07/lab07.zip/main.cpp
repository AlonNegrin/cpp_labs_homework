#include <iostream>
#include <string>
#include <fstream>
#include "Robot.h"
#include "Transformer.h"
#include "WallE.h"
#include "Terminator.h"

using namespace std;
int main() {

    ifstream file("tracks.txt");
    if(file.is_open())
    {
        string tracks[5];
        for(auto & track : tracks)
        {
            file >> track;
        }
    }
    Robot *robots[4];
    robots[0] = new Robot();
    robots[1] = new Transformer();
    robots[2] = new Terminator();
    robots[3] = new WallE();


    return 0;
}
