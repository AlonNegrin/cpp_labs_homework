#include <iostream>
#include "Game.h"

int main(int argc, char *argv[]) {
    if (argc != 2) {
        std::cerr << "Invalid run arguments; run the game with board size." << std::endl;
        return -1;
    }
    Game game(stoi(argv[1]));
    game.play();
    return 0;
}
